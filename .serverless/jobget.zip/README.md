# jobgetwebsite
To deploy:

	npm install
	serverless config credentials --provider aws --key AKIAIOSFODNN7EXAMPLE --secret wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
	serverless deploy
	serverless client deploy
